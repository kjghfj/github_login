package com.goushikhan.githublogin;
/*Created by juniordamacena on 24/07/2017.*/

public class ResultCode {
    public static final int SUCCESS = 1;
    public static final int ERROR = 2;
}
